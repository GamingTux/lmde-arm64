# Xenity

Xenity is a drop-in replacement for Zenity 3.44 (GTK3).

Changes are kept to a minimum.

Alternatives:

- Yad (Also GTK3 but slightly different look. Different exit codes, features, syntax): https://github.com/v1cont/yad
- Zenity 4+ (Moved to GTK4/libadwaita, very different look, different features, syntax): https://gitlab.gnome.org/GNOME/zenity

## Differences with Zenity 3.44

Removed options:

- `--about`. There was no need for this. The UI part of Xenity is meant for scripts and apps. Users use the CLI, the man page and the `--version` option.
- `--url`, `--html`, `--no-interaction`. These were rarely used and depended on libwebkitgtk. URLs can be shown with `xdg-open` instead.
- `--notification`, `--listen`, `--hint`. These options were rarely used and depended on libnotify. Notifications can be shown with `notify-send` instead.

Removed features:

- `/usr/bin/gdialog`. Old GNOME 1 wrapper. Removed to make it possible to backport Xenity to older releases and have it installed alongside Zenity 3x without conflicts.
- Yelp catalogue. Not something we want to maintain, only visible with Yelp.

## License

This software is licensed under the LGPL.

## Dependencies

- gtk+-3.16

