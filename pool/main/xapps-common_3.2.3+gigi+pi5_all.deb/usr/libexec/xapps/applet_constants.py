LOCALEDIR = "/usr/share/locale"
PKGVERSION = "3.2.3"