set(LIBGAV1_INCLUDE_DIRS "/usr/include")
set(LIBGAV1_LIBRARIES "gav1")
