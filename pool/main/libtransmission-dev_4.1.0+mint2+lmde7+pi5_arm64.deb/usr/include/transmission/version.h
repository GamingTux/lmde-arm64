#pragma once

#define PEERID_PREFIX             "-TR410B-"
#define USERAGENT_PREFIX          "4.1.0-beta.2"
#define VCS_REVISION              "ac5c9e082d"
#define VCS_REVISION_NUM          ac5c9e082d
#define SHORT_VERSION_STRING      "4.1.0-beta.2"
#define LONG_VERSION_STRING       "4.1.0-beta.2 (ac5c9e082d)"
#define VERSION_STRING_INFOPLIST  4.1.0-beta.2
#define BUILD_STRING_INFOPLIST    14718.1.2
#define MAJOR_VERSION             4
#define MINOR_VERSION             1
#define PATCH_VERSION             0

#define TR_BETA_RELEASE 1
/* #undef TR_NIGHTLY_RELEASE */
/* #undef TR_STABLE_RELEASE */
